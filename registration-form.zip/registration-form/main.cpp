#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "DatabaseManager.h"

static QObject *dbmanager_provider(QQmlEngine *, QJSEngine *)
{
    return new DatabaseManager();
}

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;

    qmlRegisterSingletonType<DatabaseManager>("App", 1, 0, "DBManager", dbmanager_provider);

    // Load from the correct path
    engine.load(QUrl(QStringLiteral("registration-form/Main.qml")));

    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}

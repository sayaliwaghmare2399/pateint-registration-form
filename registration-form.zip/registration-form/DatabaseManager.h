#pragma once
#include <QDebug>
#include <QObject>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

class DatabaseManager : public QObject
{
    Q_OBJECT
public:
    explicit DatabaseManager(QObject *parent = nullptr)
        : QObject(parent)
    {
        db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("patients.db");

        if (!db.open()) {
            qDebug() << "DB Open Failed:" << db.lastError().text();
        } else {
            QSqlQuery query;
            query.exec("CREATE TABLE IF NOT EXISTS patients ("
                       "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                       "consultation_id TEXT UNIQUE, "
                       "dob TEXT, "
                       "name TEXT, "
                       "mobile TEXT UNIQUE, "
                       "gender TEXT)");
        }
    }

    Q_INVOKABLE QString registerPatient(const QString &consultationId,
                                        const QString &dob,
                                        const QString &name,
                                        const QString &mobile,
                                        const QString &gender)
    {
        if (consultationId.trimmed().isEmpty() || dob.trimmed().isEmpty()
            || name.trimmed().isEmpty() || mobile.trimmed().isEmpty()
            || gender.trimmed().isEmpty()) {
            return "All fields are required.";
        }

        QSqlQuery query;
        query.prepare("INSERT INTO patients "
                      "(consultation_id, dob, name, mobile, gender) "
                      "VALUES (:consultation_id, :dob, :name, :mobile, :gender)");
        query.bindValue(":consultation_id", consultationId);
        query.bindValue(":dob", dob);
        query.bindValue(":name", name);
        query.bindValue(":mobile", mobile);
        query.bindValue(":gender", gender);

        if (!query.exec()) {
            if (query.lastError().nativeErrorCode() == "19") {
                return "User already registered.";
            }
            return "Registration failed: " + query.lastError().text();
        }
        return "Registration complete!";
    }

private:
    QSqlDatabase db;
};
